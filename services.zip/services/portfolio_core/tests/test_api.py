"""Tests for API endpoints."""
import pytest
import asyncio
from fastapi.testclient import TestClient
from datetime import datetime, timezone

from app.main import app
from app.db import init_db


@pytest.fixture
def client():
    """Test client fixture."""
    # Initialize database before creating test client
    asyncio.run(init_db("/tmp/test_portfolio.db"))
    return TestClient(app)


@pytest.fixture
def mock_user_params():
    """Mock user parameters for requests."""
    return {
        "user_id": 12345,
        "first_name": "Test",
        "last_name": "User",
        "username": "testuser",
        "language_code": "en"
    }


def test_health_endpoint(client):
    """Test health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert data["data"]["status"] == "healthy"


def test_portfolio_endpoint(client, mock_user_params):
    """Test /portfolio endpoint."""
    response = client.get("/portfolio", params=mock_user_params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "portfolio" in data["data"]


def test_cash_endpoint(client, mock_user_params):
    """Test /cash endpoint."""
    response = client.get("/cash", params=mock_user_params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "cash_balance" in data["data"]


def test_add_position_endpoint(client, mock_user_params):
    """Test /add endpoint."""
    params = mock_user_params.copy()
    params.update({
        "qty": 10,
        "symbol": "AAPL.US",
        "type": "stock"
    })

    response = client.post("/add", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "position" in data["data"]


def test_transactions_endpoint(client, mock_user_params):
    """Test /tx endpoint."""
    params = mock_user_params.copy()
    params["limit"] = 5

    response = client.get("/tx", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "transactions" in data["data"]


def test_allocation_endpoint(client, mock_user_params):
    """Test /allocation endpoint."""
    response = client.get("/allocation", params=mock_user_params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "allocation" in data["data"]


def test_portfolio_snapshot_endpoint(client, mock_user_params):
    """Test /portfolio_snapshot endpoint."""
    params = mock_user_params.copy()
    params["period"] = "d"

    response = client.get("/portfolio_snapshot", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "snapshot" in data["data"]


def test_help_endpoint(client, mock_user_params):
    """Test /help endpoint."""
    response = client.get("/help", params=mock_user_params)
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "help" in data["data"]
    assert isinstance(data["data"]["help"], list)