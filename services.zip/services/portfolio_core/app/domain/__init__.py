"""
Domain models and business logic.
"""