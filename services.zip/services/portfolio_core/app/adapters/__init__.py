"""
Adapters for external service integration.
"""