from __future__ import annotations

from typing import Any, Dict

from ..connectors.http import HTTPClient
from ..connectors.market_data import MarketDataClient
from ..connectors.portfolio_core import PortfolioCoreClient
from ..connectors.fx import FXClient


class Dispatcher:
    def __init__(self, http: HTTPClient):
        self.http = http
        self.market_data = MarketDataClient(http)
        self.portfolio = PortfolioCoreClient(http)
        self.fx = FXClient(http)

    async def dispatch(self, spec: Dict[str, Any], args: Dict[str, Any], user_context: Dict[str, Any] = None) -> Dict[str, Any]:
        service = spec.get("service")
        method = spec.get("method", "GET").upper()
        path = spec.get("path", "/")
        args_map: Dict[str, str] = spec.get("args_map", {})
        payload: Dict[str, Any] = {to: args.get(frm) for frm, to in args_map.items()}

        # Add user context for portfolio_core calls
        if service == "portfolio_core" and user_context:
            payload.update(user_context)

        # Market data
        if service == "market_data":
            if path == "/quote" and method == "GET":
                symbols = payload.get("symbols") or []
                if isinstance(symbols, str):
                    symbols = [symbols]
                try:
                    return await self.market_data.get_quotes(symbols=symbols)
                except Exception as e:
                    return {"ok": False, "error": {"code": "UPSTREAM_ERROR", "message": str(e), "source": "market_data", "retriable": True}}

        # FX
        if service == "fx":
            if path == "/fx" and method == "GET":
                base = (payload.get("base") or "").strip()
                quote = (payload.get("quote") or "").strip()
                if not base or not quote:
                    # Signal UI prompt for /fx
                    return {"ok": True, "data": {"fx_prompt": True}}
                try:
                    data = await self.fx.get_fx(base=base, quote=quote, force=True)
                    # Wrap raw FX payload in envelope for router flow
                    return {"ok": True, "data": data}
                except Exception as e:
                    return {"ok": False, "error": {"code": "UPSTREAM_ERROR", "message": str(e), "source": "fx", "retriable": True}}

        # Portfolio core
        if service == "portfolio_core":
            if path == "/buy" and method == "POST":
                return await self.portfolio.post_buy(payload)
            if path == "/sell" and method == "POST":
                return await self.portfolio.post_sell(payload)

            # Generic passthrough using HTTP client (until dedicated methods are added)
            base = self.portfolio.base
            url = f"{base}{path}"
            try:
                if method == "GET":
                    return (await self.http.request("GET", url, params=payload)).json()
                if method == "POST":
                    return (await self.http.request("POST", url, json=payload)).json()
            except Exception as e:
                return {"ok": False, "error": {"code": "UPSTREAM_ERROR", "message": str(e), "source": "portfolio_core", "retriable": True}}

        # Unknown mapping
        return {"ok": False, "error": {"code": "unknown_dispatch", "message": f"No route for {service} {method} {path}"}}
