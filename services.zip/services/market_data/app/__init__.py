"""App package marker for reliable imports in Docker.

FastAPI is served as `uvicorn app.main:app`.
"""

